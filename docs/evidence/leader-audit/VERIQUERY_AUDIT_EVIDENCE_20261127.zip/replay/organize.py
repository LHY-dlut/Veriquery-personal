"""Create one evidence file per case while retaining complete raw artifacts."""
from collections import defaultdict
import json
from pathlib import Path
import sys


root = Path(sys.argv[1])
cases = root / "cases"
cases.mkdir(exist_ok=True)
events = defaultdict(list)
for line in (root / "events.jsonl").read_text(encoding="utf8").splitlines():
    event = json.loads(line)
    events[event["session"]].append(event)
summary = json.loads((root / "case-index.json").read_text(encoding="utf8"))
for line in (root / "answers.jsonl").read_text(encoding="utf8").splitlines():
    result = json.loads(line)
    case_id = result["id"]
    session = result["request"]["session_id"]
    receipt = {
        "api": result,
        "stage_index": summary[case_id],
        "events": events[session],
    }
    ui_path = root / f"{case_id}-ui.json"
    if ui_path.exists():
        ui = json.loads(ui_path.read_text(encoding="utf8"))
        ui_session = summary[case_id]["ui"]["session"]
        receipt["ui"] = ui
        receipt["ui_events"] = events[ui_session]
    (cases / f"{case_id}.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf8")
