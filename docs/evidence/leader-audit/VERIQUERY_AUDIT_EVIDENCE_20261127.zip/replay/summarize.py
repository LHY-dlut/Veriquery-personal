"""Generate case-by-case evidence pointers from the captured audit events."""
from collections import defaultdict
import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
gold = json.loads(Path(sys.argv[2]).read_text(encoding="utf8"))
docs = json.loads((root/"documents.json").read_text(encoding="utf8"))
by_session = defaultdict(list)
for line in (root/"events.jsonl").read_text(encoding="utf8").splitlines():
    event = json.loads(line)
    by_session[event["session"]].append(event)

ranked_branches = defaultdict(dict)
for session, events in by_session.items():
    for event in events:
        if event["branch"]:
            key = event["path"] if event["stage"] == "backend_http" else event["stage"]
            ranked_branches[session, event["branch"]][key] = event
for stages in ranked_branches.values():
    fusion = stages["_rrf_fusion_input"]
    streams = defaultdict(list)
    for hit in fusion["hits"]:
        streams[hit["source"]].append(hit)
    scores = defaultdict(float)
    for source, rows in streams.items():
        for rank, hit in enumerate(sorted(rows, key=lambda hit: -hit["score"]), 1):
            scores[hit["doc"], hit["id"]] += fusion["weights"].get(source, .1) / (fusion["args"]["k"] + rank)
    for hit in stages["_rrf_fusion_output"]["hits"]:
        assert abs(hit["metadata"]["rrf_score"] - scores[hit["doc"], hit["id"]]) < 1e-10
    wire = stages["/v1/rerank"]
    pre = stages["_rerank_candidates_input"]["hits"]
    texts = []
    for hit in pre:
        meta = hit["metadata"]
        text = ("\n".join(filter(None, [meta.get("table_header"), meta.get("focused_text") or hit["text"]]))
                if meta.get("focused_row") else hit["text"])
        texts.append(text)
    assert texts == wire["request"]["documents"]
    scored = {row["index"]: row["relevance_score"] for row in wire["reply"]["results"]}
    order = [pre[i]["id"] for i in sorted(scored, key=scored.get, reverse=True)]
    order.extend(hit["id"] for i, hit in enumerate(pre) if i not in scored)
    assert order == [hit["id"] for hit in stages["_rerank_candidates_output"]["hits"]]

def compact(s):
    return "".join(s.split())


def candidates(event):
    return event.get("hits", event.get("results", []))


def rank_hits(rows, doc, page, quotes):
    return [
        {"rank":rank,"chunk_id":r.get("id",r.get("chunk_id")), "score":r.get("score")}
        for rank,r in enumerate(rows,1)
        if r.get("doc",r.get("document_id")) == doc and r["page"] == page
        and all(q in compact(((r.get("metadata") or {}).get("table_header") or "")
                             + r.get("text",r.get("text_snippet", ""))) for q in quotes)
    ]


stage_names = ["_vector_retrieve_output","retrieve_lexical_output","_table_retrieve_output",
               "_rrf_fusion_output","_rerank_candidates_input","_rerank_candidates_output",
               "_limit_results_output","retrieve_output"]
result = {}
for line in (root/"answers.jsonl").read_text(encoding="utf8").splitlines():
    r=json.loads(line)
    qid=r["id"]
    answer=r["response"]
    trace=answer["trace"]
    sid=r["request"]["session_id"]
    events=by_session[sid]
    entry=next(e for e in events if e["stage"]=="graph_entry")
    assert entry["arguments"]["query"]==r["request"]["query"]
    assert entry["arguments"]["doc_ids"]==r["request"]["document_ids"]
    context=next(e for e in events if e["stage"]=="assembled")
    assert context["context"]==trace["context"]
    graph=next(e for e in events if e["stage"]=="graph_output")
    calls=[e for e in events if e["stage"]=="backend_http" and e["path"].endswith("/chat/completions")]
    if calls:
        first=calls[0]["request"]
        assert first["max_tokens"]==512 and context["context"] in first["messages"][0]["content"]
        assert all(call["reply"]["model"]=="qwen3.5" for call in calls)
    branches={}
    for branch in dict.fromkeys(e["branch"] for e in events if e["branch"]):
        stages={e["stage"]:e for e in events if e["branch"]==branch}
        branches[branch]={
            "candidate_counts":{n:len(candidates(stages[n])) for n in stage_names if n in stages},
            "raw_counts":{n:len(e["rows"]) for n,e in stages.items() if n.endswith("Store_raw")},
            "stages":stages,
        }
    visible=[]
    markers=list(re.finditer(r"(?m)^\[(\d+)\] ([^\n]+?) 第(\d+)页",context["context"]))
    assert len(markers)==len(context["sources"])
    for i,(m,s) in enumerate(zip(markers,context["sources"])):
        assert (int(m[1]),m[2],int(m[3]))==(i+1,s["file"],s["page"])
        end=markers[i+1].start() if i+1<len(markers) else len(context["context"])
        visible.append({**s,"text":context["context"][m.end():end]})
    facts={}
    for key in gold["cases"][qid]:
        item=gold["facts"][key]
        doc=docs[item["document"]]["document_id"]
        page=item["page"]
        quotes=[compact(q) for q in item["quotes"]]
        facts[key]={
            "stage_hits":{b:{n:rank_hits(candidates(x["stages"][n]),doc,page,quotes)
                            for n in stage_names if n in x["stages"]} for b,x in branches.items()},
            "top8":rank_hits(trace["retrieved"][:8],doc,page,quotes),
            "context":rank_hits(visible,doc,page,quotes),
            "citations":rank_hits(answer["citations"],doc,page,quotes),
        }
    result[qid]=dict(session=sid, answer_mode=trace["answer_mode"],
                     model_calls=[{"tokens":e["reply"].get("usage"),"finish_reason":e["reply"]["choices"][0]["finish_reason"]}
                                  for e in calls],
                     graph_api_match=graph["answer"]==answer["response"], facts=facts,
                     branches={b:{k:v for k,v in d.items() if k!="stages"} for b,d in branches.items()})

for path in root.glob("*-ui.json"):
    u=json.loads(path.read_text(encoding="utf8"))
    end=next(e["data"] for e in u["request"]["events"] if e["type"]=="complete")
    assembled="".join(e["data"]["chunk"] for e in u["request"]["events"] if e["type"]=="chunk")
    assert assembled==end["response"]==u["ui_history_entry"]["content"]==u["rendered_text"]
    assert end["citations"]==u["ui_history_entry"]["citations"]
    event=next(e for e in by_session[end["session_id"]] if e["stage"]=="graph_entry")
    assert event["arguments"]["query"]==u["request"]["body"]["query"]
    assert event["arguments"]["doc_ids"]==u["request"]["body"]["document_ids"]
    result[u["id"]]["ui"] = {"session": end["session_id"], "citations":len(end["citations"]),
                             "expanded_sources":u["rendered_html"].count("<details>")}
print(json.dumps(result,ensure_ascii=False,indent=2))
