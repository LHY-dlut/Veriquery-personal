set -euo pipefail
r=$1
cd "$r/app"
prev=/root/autodl-tmp/veriquery-formula-ab.hqPa8I
py=/root/autodl-tmp/Veriquery-personal/.venv/bin/python
source "$prev/runtime-env.sh" "$PWD" 8221 qwen3.5 http://127.0.0.1:9997/v1
export LLM_MAX_TOKENS=512
"$py" "$r/observe.py" "$r/events.jsonl" 8221 >"$r/chat-api.log" 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT
for i in $(seq 1 90); do
    curl -fsS --max-time 2 http://127.0.0.1:8221/health >/dev/null 2>&1 && break
    kill -0 "$pid"
    sleep 1
done
"$py" "$r/ask.py" "$r" n02,n03,n04,n06,n07,n10,v1,v2,v3
"$py" "$r/ui_probe.py" "$r" n04,n06,n07,n10
