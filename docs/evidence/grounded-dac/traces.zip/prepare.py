import json
from pathlib import Path
import sys
import fitz

root = Path.cwd()
sys.path.insert(0, str(root / "hold/app/eval"))
from run_pilot import upload

docs = {}
for part, pages in [("DAC081S101", [1, 6, 14]), ("DAC7311", [1, 22])]:
    with fitz.open(root / f"{part.lower()}-full.pdf") as source, fitz.open() as pdf:
        for page in pages:
            pdf.insert_pdf(source, from_page=page-1, to_page=page-1)
        output = root / f"{part}.pdf"
        pdf.save(output)
    doc = upload("http://127.0.0.1:8288", output, 800)
    if doc["parser_tier"] != "advanced" or doc["parser"] != "mineru":
        raise ValueError(doc)
    docs[part] = doc
    (root / "hold/docs.json").write_text(json.dumps(docs, ensure_ascii=False))
    print(part, doc["document_id"], doc["chunk_count"], flush=True)
