"""Join real API responses, model receipts and case-level strict reviews."""
import hashlib
import json
from pathlib import Path
from statistics import median
import zipfile

p = Path(__file__).resolve().parent
repo = p.parents[2]
dest = repo / "docs/evidence/grounded-dac"
dest.mkdir(parents=True, exist_ok=True)


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf8").splitlines()]


questions = {r['id']: r for r in rows(repo / 'data/eval/output-context/questions.jsonl') + rows(p/'unseen.jsonl')}
scores = json.loads((p/'grades.json').read_text(encoding='utf8'))
arms = ['baseline', 'candidate', 'unseenbefore', 'unseenafter']
records, summary, files = [], {}, []
seen = set()
for arm in arms:
    data = rows(p/f'{arm}.jsonl')
    calls = rows(p/f'model-calls-{arm}.jsonl')
    assert len(data) == (12 if arm.startswith('unseen') else 18)
    assert all(c['requested_model'] == c['returned_model'] == 'qwen3.5' and c['success'] for c in calls)
    assert {c['session_id'] for c in calls} <= {r['session_id'] for r in data}
    expected_cases = {k for k in questions if k.startswith('u' if arm.startswith('unseen') else 'n')}
    assert {(r['id'],r['repeat']) for r in data} == {(k,i) for k in expected_cases for i in (1,2,3)}
    for row in data:
        k, i, session = row['id'], row['repeat'], row['session_id']
        assert session not in seen
        seen.add(session)
        q, body, pred = questions[k], row['request'], row['prediction']
        assert pred['success'] and body['query'] == q['query'] and pred['session_id'] == session
        trace = pred['trace']
        cc = [c for c in calls if c['session_id'] == session]
        if cc:
            assert cc[0]['max_tokens'] == 512
        program = trace['answer_mode'] == 'verified_dac_calculation'
        if program:
            assert not cc
            for cite in pred['citations']:
                assert cite['text_snippet'] in trace['context']
                assert any(cite['text_snippet'] == e['text_snippet'] and e['document_id'] in body['document_ids']
                           for e in trace['context_evidence'])
        if arm == 'candidate' and k in ('n02','n04','n10'):
            assert program
        if arm == 'candidate' and k == 'n10':
            assert 'n = 1 2' in pred['citations'][0]['text_snippet']
            snippet = pred['citations'][1]['text_snippet']
            assert 'MIN | TYP | MAX | UNIT' in snippet and '495 | 500 | 505 | mV' in snippet
            assert 'PS/SYNC' in snippet and 'TPS63020 feedback voltage' in snippet
        grade, why = scores[arm][k][i-1]
        records.append(dict(arm=arm,id=k,i=i,session=session,passed=grade,why=why,
                            answer=pred['response'],citations=pred['citations'],mode=trace['answer_mode'],
                            tokens=[c['usage']['completion_tokens'] for c in cc],seconds=row['seconds']))
    group=[r for r in records if r['arm']==arm]
    summary[arm] = dict(strict=sum(r['passed'] for r in group),requests=len(group),
                        by_id={k:sum(r['passed'] for r in group if r['id']==k) for k in sorted(expected_cases)},
                        deterministic=sum(r['mode']=='verified_dac_calculation' for r in group),
                        llm_calls=len(calls),p50=median(r['seconds'] for r in group))
    files.extend([p/f'{arm}.jsonl',p/f'model-calls-{arm}.jsonl'])

doc=['# 真实 API 逐份评分','', '每题分别在改前与改后新建三个会话。引用中的页码为上传选页内的页码。完整引用原文、召回记录、入模消息和原始模型回复见同目录 traces.zip。','']
for k,q in questions.items():
    doc += [f'## {k}','',q['query'],'','参考答案　'+q['gold'],'']
    for r in (v for v in records if v['id']==k):
        verdict='通过' if r['passed'] else '未通过'
        doc += [f"### {r['arm']} · 第 {r['i']} 次",'',f"**{verdict}**　{r['why']}",'',
                f"会话 `{r['session']}`，路径 `{r['mode']}`，各次大模型输出 token 为 {r['tokens']}。",'',
                '```text',r['answer'],'```','']
        for index,c in enumerate(r['citations'],1):
            doc.append(f"- [{index}] {c['file']}，选页第 {c['page']} 页。")
        doc.append('')
(dest/'answers.md').write_text('\n'.join(doc),encoding='utf8')
(p/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
files += [p/x for x in ['grades.json','summary.json','unseen.jsonl','sources.sha256','docs.json',
                        'hold-index.json','heldout-indexed.json','regressions.log','prepare.py','manifest.json']]
files += [repo/'data/eval/output-context/questions.jsonl', Path(__file__)]
with zipfile.ZipFile(dest/'traces.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in files:
        z.write(f,f.name)
print(json.dumps(summary))
