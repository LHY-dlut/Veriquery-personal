"""Record independent real HTTP conversations against a single local experiment instance."""
import json
from pathlib import Path
import sys
import time
import uuid

import requests


root, arm, cases = Path(sys.argv[1]), sys.argv[2], sys.argv[3].split(",")
port = 8280
questions = [json.loads(line) for line in (root / "questions.jsonl").read_text().splitlines()]
docs = {"MCP4725": "c06748dc", "TPS63020": "386a2473"}
with requests.Session() as client, (root / f"{arm}.jsonl").open("x", encoding="utf8") as out:
    for repeat in range(1, 4):
        for q in questions:
            if q["id"] not in cases:
                continue
            session = str(uuid.uuid4())
            key = dict(id=q["id"], repeat=repeat, session_id=session)
            body = dict(query=q["query"], document_ids=[docs[p] for p in q["parts"]], session_id=session, trace=True)
            (root / f"active-{arm}.json").write_text(json.dumps(key))
            start = time.monotonic()
            r = client.post(f"http://127.0.0.1:{port}/api/v1/chat/", json=body, timeout=240)
            r.raise_for_status()
            result = r.json()
            if not result["success"] or result["session_id"] != session:
                raise RuntimeError((key, result.get("response")))
            record = dict(**key, request=body, prediction=result, seconds=round(time.monotonic()-start,3))
            out.write(json.dumps(record, ensure_ascii=False) + "\n")
            out.flush()
            print(arm, repeat, q["id"], record["seconds"], flush=True)
