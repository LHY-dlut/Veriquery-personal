set -euo pipefail
r=$1
arm=$2
tokens=$3
cases=$4
prev=/root/autodl-tmp/veriquery-formula-ab.hqPa8I
py=/root/autodl-tmp/Veriquery-personal/.venv/bin/python
cd "$r/app"
base=http://127.0.0.1:8285/v1
source "$prev/runtime-env.sh" "$PWD" 8280 qwen3.5 "$base"
export LLM_MAX_TOKENS="$tokens"
"$py" "$r/tap.py" --root "$r" --port 8285 --arm "$arm" --expected-model qwen3.5 >"$r/$arm-tap.log" 2>&1 &
tap=$!
bash "$prev/start-app.sh" "$PWD" 8280 qwen3.5 "$base" >"$r/$arm-api.log" 2>&1 &
app=$!
trap 'kill "$app" "$tap" 2>/dev/null || true; wait "$app" "$tap" 2>/dev/null || true' EXIT
for i in $(seq 1 90); do
    if curl -fsS --max-time 2 http://127.0.0.1:8280/health >/dev/null 2>&1; then break; fi
    kill -0 "$app" "$tap"
    sleep 1
done
"$py" "$r/run_arm.py" "$r" "$arm" "$cases"
