import json
import sys
from pathlib import Path
import fitz

p = Path.cwd()
sys.path.insert(0, str(p/"app/eval"))
from run_pilot import upload

with fitz.open("adi-full.pdf") as d, fitz.open() as sample:
    for index in (0, 7):
        sample.insert_pdf(d, from_page=index, to_page=index)
    sample.save("AD5300.pdf")
docs = json.loads(Path("docs.json").read_text())
entry = upload("http://127.0.0.1:8288", p/"AD5300.pdf", 800)
assert entry["parser"] == "mineru" and entry["parser_tier"] == "advanced"
docs.update(AD5300=entry, MCP4725={"document_id":"c06748dc"}, TPS63020={"document_id":"386a2473"})
Path("docs.json").write_text(json.dumps(docs,ensure_ascii=False))
