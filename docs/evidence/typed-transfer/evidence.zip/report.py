import html
import json
from pathlib import Path
import tarfile
import zipfile

p = Path(__file__).resolve().parent
dest = p.parents[2]/'docs/evidence/typed-transfer'
dest.mkdir(parents=True, exist_ok=True)
g = json.loads((p/'grades.json').read_text(encoding='utf8'))
with tarfile.open(p/'receipts.tar.gz') as archive:
    files = {m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
    def lines(name):
        return [json.loads(l) for l in files[name].splitlines()]
    cases = {q['id']:q for q in lines('questions.jsonl')}
    result = {}
    by_case = {k:[] for k in cases}
    for arm,prefix in [('before',''),('after','candidate/')]:
        rows = lines(prefix+arm+'.jsonl')
        calls = lines(prefix+'model-calls-'+arm+'.jsonl')
        assert len({(r['id'],r['repeat']) for r in rows}) == len(rows) == 30
        assert len({r['session_id'] for r in rows})==30
        assert {r['session_id'] for r in calls} <= {r['session_id'] for r in rows}
        summary = {k:0 for k in cases}
        verified = 0
        for r in rows:
            k, rep = r['id'], r['repeat']
            a = r['prediction']
            assert r['request']['query']==cases[k]['query'] and a['success']
            t = a['trace']
            rc = [c for c in calls if c['session_id']==r['session_id']]
            assert all(c['success'] and c['returned_model']==c['requested_model']=='qwen3.5' for c in rc)
            if rc:
                assert rc[0]['max_tokens']==512
            if t['answer_mode']=='verified_dac_calculation':
                verified += 1
                assert not rc
                for c in a['citations']:
                    assert c['text_snippet'] in t['context']
                    if arm=='after':
                        assert c['document_id'] in r['request']['document_ids']
                        assert any(x['chunk_id']==c['chunk_id'] and x['document_id']==c['document_id']
                                   and x['text_snippet']==c['text_snippet'] for x in t['context_evidence'])
            score,why=g[arm][k][rep-1]
            assert isinstance(why,str) and why
            summary[k]+=score
            by_case[k] += [f"### {arm} · 第 {rep} 次","",
                            ("**通过**　" if score else "**未通过**　")+why,"",
                            f"会话 `{r['session_id']}`，路径 `{t['answer_mode']}`。","",
                            "```text",a['response'],"```",""]
            for i,c in enumerate(a['citations'],1):
                by_case[k].append(f"- [{i}] {c['file']}，选页第 {c['page']} 页，片段 {c.get('chunk_id') or '旧接口未返回标识'}。")
            by_case[k].append("")
        result[arm]=dict(by_question=summary,strict=sum(summary.values()),requests=len(rows),
                         program=verified,model_calls=len(calls))
    ui = json.loads(files['n04-ui.json'])
    cites = ui['ui_history_entry']['citations']
    assert len(cites)==2 and len({v['chunk_id'] for v in cites})==2 and len({v['page'] for v in cites})==1
    for i,c in enumerate(cites,1):
        assert f"[{i}] " in ui['rendered_html'] and html.escape(c['text_snippet']).replace('\n','<br>') in ui['rendered_html']
    assert 'Ran 37 tests' in files['tests.log'].decode() and files['tests.log'].decode().strip().endswith('OK')
    md=['# 逐次问答与评分','','每个版本每道题独立请求两次。原始 JSONL 包含精确引用片段、请求体与工作流记录。','']
    for k,q in cases.items():
        md += [f"## {k}","",q['query'],"","评分依据　"+q['gold'],"",*by_case[k]]
    (dest/'answers.md').write_text('\n'.join(md),encoding='utf8')
    with zipfile.ZipFile(dest/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
        for n,b in files.items():
            z.writestr(n,b)
        for n in ['grades.json','report.py','prepare.py']:
            z.write(p/n,n)
        z.writestr('summary.json',json.dumps(result,indent=2))
    print(json.dumps(result))
