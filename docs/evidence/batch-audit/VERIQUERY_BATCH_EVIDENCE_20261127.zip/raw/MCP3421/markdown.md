## 1.0 ELECTRICAL CHARACTERISTICS

## 1.1 Absolute Maximum Ratings†

$\nabla _ { \mathrm { D D } }$ .......7.0V

All inputs and outputs $\operatorname { w . r . t } \nabla _ { \mathbb { S } \mathbb { S } }$ ...... –0.3V to $\mathsf { V _ { D D } } { \scriptstyle + 0 . 3 \mathsf { V } }$

Differential Input Voltage .... $| \nabla _ { \mathsf { D D } } \cdot \nabla _ { \mathsf { S S } } |$

Output Short Circuit Current .. ............ Continuous

Current at Input Pins . .....±2 mA

Current at Output and Supply Pins ............................ ±10 mA

Storage Temperature .... $-65^{\circ}C \mathrm{t}0 + 150^{\circ}C$

Ambient Temp. with power applied ............... $-55^{\circ}C \mathrm{t}0 + 125^{\circ}C$

ESD protection on all pins ................ ≥ 6 kV HBM, ≥ 400V MM

Maximum Junction Temperature (T<sub>J</sub>) . .................. $+ 1 5 0 ^ { \circ } \mathbf { C }$ **†Notice:** Stresses above those listed under “Maximum Ratings” may cause permanent damage to the device. This is a stress rating only and functional operation of the device at those or any other conditions above those indicated in the operational listings of this specification is not implied. Exposure to maximum rating conditions for extended periods may affect device reliability.

## 1.2 Electrical Specifications

## ELECTRICAL CHARACTERISTICS

<table><tr><td colspan="7">Electrical Specifications: Unless otherwise specified, all parameters apply for  $T_A = -40°C to +85°C$ ,  $V_{DD} = +5.0V$ ,  $V_{SS} = 0V$ ,  $V_{IN}+ = V_{IN^-} = V_{REF}/2$ . All ppm units use  $2*V_{REF}$  as full scale range.</td></tr><tr><td>Parameters</td><td>Sym</td><td>Min</td><td>Typ</td><td>Max</td><td>Units</td><td>Conditions</td></tr><tr><td colspan="7">Analog Inputs</td></tr><tr><td>Differential Input Range</td><td></td><td>—</td><td>±2.048/PGA</td><td>—</td><td>V</td><td> $V_{IN} = V_{IN}+ - V_{IN^-}$ </td></tr><tr><td>Common-Mode Voltage Range (absolute) (Note 1)</td><td></td><td> $V_{SS}-0.3$ </td><td>—</td><td> $V_{DD}+0.3$ </td><td>V</td><td></td></tr><tr><td>Differential Input Impedance (Note 2)</td><td> $Z_{IND}$ (f)</td><td>—</td><td>2.25/PGA</td><td>—</td><td>MΩ</td><td>During normal mode operation</td></tr><tr><td>Common Mode input Impedance</td><td> $Z_{INC}$ (f)</td><td>—</td><td>25</td><td>—</td><td>MΩ</td><td>PGA = 1, 2, 4, 8</td></tr><tr><td colspan="7">System Performance</td></tr><tr><td rowspan="4">Resolution and No Missing Codes (Note 8)</td><td rowspan="4"></td><td>12</td><td>—</td><td>—</td><td>Bits</td><td>DR = 240 SPS</td></tr><tr><td>14</td><td>—</td><td>—</td><td>Bits</td><td>DR = 60 SPS</td></tr><tr><td>16</td><td>—</td><td>—</td><td>Bits</td><td>DR = 15 SPS</td></tr><tr><td>18</td><td>—</td><td>—</td><td>Bits</td><td>DR = 3.75 SPS</td></tr><tr><td rowspan="4">Data Rate (Note 3)</td><td rowspan="4">DR</td><td>176</td><td>240</td><td>328</td><td>SPS</td><td>S1,S0 = &#x27;00&#x27;, (12 bits mode)</td></tr><tr><td>44</td><td>60</td><td>82</td><td>SPS</td><td>S1,S0 = &#x27;01&#x27;, (14 bits mode)</td></tr><tr><td>11</td><td>15</td><td>20.5</td><td>SPS</td><td>S1,S0 = &#x27;10&#x27;, (16 bits mode)</td></tr><tr><td>2.75</td><td>3.75</td><td>5.1</td><td>SPS</td><td>S1,S0 = &#x27;11&#x27;, (18 bits mode)</td></tr><tr><td>Output Noise</td><td></td><td>—</td><td>1.5</td><td>—</td><td>μ $V_{RMS}$ </td><td> $T_A = +25°C$ , DR = 3.75 SPS, PGA = 1,  $V_{IN} = 0$ </td></tr><tr><td>Integral Nonlinearity (Note 4)</td><td>INL</td><td>—</td><td>10</td><td>35</td><td>ppm of FSR</td><td>DR = 3.75 SPS (Note 6)</td></tr><tr><td>Internal Reference Voltage</td><td> $V_{REF}$ </td><td>—</td><td>2.048</td><td>—</td><td>V</td><td></td></tr></table>

Note 1: Any input voltage below or greater than this voltage causes leakage current through the ESD diodes at the input pins. This parameter is ensured by characterization and not 100% tested.

2: This input impedance is due to 3.2 pF internal input sampling capacitor.

3: The total conversion speed includes auto-calibration of offset and gain.

4: INL is the difference between the endpoints line and the measured code at the center of the quantization band.

5: Includes all errors from on-board PGA and $\mathsf { V } _ { \mathsf { R E F } }$

6: Full Scale Range (FSR) = 2 x 2.048/PGA = 4.096/PGA.

7: This parameter is ensured by characterization and not 100% tested.

8: This parameter is ensured by design and not 100% tested.

ELECTRICAL CHARACTERISTICS (CONTINUED)

<table><tr><td colspan="7">Electrical Specifications: Unless otherwise specified, all parameters apply for  $T_A = -40°C to +85°C$ ,  $V_{DD} = +5.0V$ ,  $V_{SS} = 0V$ ,  $V_{IN+} = V_{IN-} = V_{REF}/2$ . All ppm units use  $2*V_{REF}$  as full scale range.</td></tr><tr><td>Parameters</td><td>Sym</td><td>Min</td><td>Typ</td><td>Max</td><td>Units</td><td>Conditions</td></tr><tr><td>Gain Error (Note 5)</td><td></td><td>—</td><td>0.05</td><td>0.35</td><td>%</td><td>PGA = 1, DR = 3.75 SPS</td></tr><tr><td>PGA Gain Error Match (Note 5)</td><td></td><td>—</td><td>0.1</td><td>—</td><td>%</td><td>Between any 2 PGA gains</td></tr><tr><td>Gain Error Drift (Note 5)</td><td></td><td>—</td><td>15</td><td>—</td><td>ppm/°C</td><td>PGA=1, DR=3.75 SPS</td></tr><tr><td>Offset Error</td><td> $V_{OS}$ </td><td>—</td><td>15</td><td>40</td><td>μV</td><td>Tested at PGA = 1 $V_{DD} = 5.0V and DR = 3.75 SPS$ </td></tr><tr><td>Offset Drift vs. Temperature</td><td></td><td>—</td><td>50</td><td>—</td><td>nV/°C</td><td> $V_{DD} = 5.0V$ </td></tr><tr><td rowspan="2">Common-Mode Rejection</td><td rowspan="2"></td><td>—</td><td>105</td><td>—</td><td>dB</td><td>at DC and PGA =1,</td></tr><tr><td>—</td><td>110</td><td>—</td><td>dB</td><td>at DC and PGA =8, $T_A = +25°C$ </td></tr><tr><td>Gain vs.  $V_{DD}$ </td><td></td><td>—</td><td>5</td><td>—</td><td>ppm/V</td><td> $T_A = +25°C$ ,  $V_{DD} = 2.7V to 5.5V$ ,PGA = 1</td></tr><tr><td>Power Supply Rejection at DC</td><td></td><td>—</td><td>100</td><td>—</td><td>dB</td><td> $T_A = +25°C$ ,  $V_{DD} = 2.7V to 5.5V$ ,PGA = 1</td></tr><tr><td colspan="7">Power Requirements</td></tr><tr><td>Voltage Range</td><td> $V_{DD}$ </td><td>2.7</td><td>—</td><td>5.5</td><td>V</td><td></td></tr><tr><td rowspan="2">Supply Current during Conversion</td><td rowspan="2"> $I_{DDA}$ </td><td>—</td><td>155</td><td>190</td><td>μA</td><td> $V_{DD} = 5.0V$ </td></tr><tr><td>—</td><td>145</td><td>—</td><td>μA</td><td> $V_{DD} = 3.0V$ </td></tr><tr><td>Supply Current during Standby Mode</td><td> $I_{DDS}$ </td><td>—</td><td>0.1</td><td>0.5</td><td>μA</td><td></td></tr><tr><td colspan="7"> $I^{2}C$  Digital Inputs and Digital Outputs</td></tr><tr><td>High level input voltage</td><td> $V_{IH}$ </td><td>0.7  $V_{DD}$ </td><td>—</td><td> $V_{DD}$ </td><td>V</td><td></td></tr><tr><td>Low level input voltage</td><td> $V_{IL}$ </td><td>—</td><td>—</td><td>0.3 $V_{DD}$ </td><td>V</td><td></td></tr><tr><td>Low level output voltage</td><td> $V_{OL}$ </td><td>—</td><td>—</td><td>0.4</td><td>V</td><td> $I_{OL} = 3 mA$ ,  $V_{DD} = +5.0V$ </td></tr><tr><td>Hysteresis of Schmitt Trigger for inputs (Note 7)</td><td> $V_{HYST}$ </td><td>0.05 $V_{DD}$ </td><td>—</td><td>—</td><td>V</td><td> $f_{SCL} = 100 kHz$ </td></tr><tr><td>Supply Current when  $I^{2}C$  bus line is active</td><td> $I_{DDB}$ </td><td>—</td><td>—</td><td>10</td><td>μA</td><td></td></tr><tr><td rowspan="2">Input Leakage Current</td><td> $I_{ILH}$ </td><td>—</td><td>—</td><td>1</td><td>μA</td><td> $V_{IH} = 5.5V$ </td></tr><tr><td> $I_{ILL}$ </td><td>-1</td><td>—</td><td>—</td><td>μA</td><td> $V_{IL} = GND$ </td></tr><tr><td colspan="7">Pin Capacitance and  $I^{2}C$  Bus Capacitance</td></tr><tr><td>Pin capacitance</td><td> $C_{PIN}$ </td><td>—</td><td>—</td><td>10</td><td>pF</td><td></td></tr><tr><td> $I^{2}C$  Bus Capacitance</td><td> $C_b$ </td><td>—</td><td>—</td><td>400</td><td>pF</td><td></td></tr></table>

Note 1: Any input voltage below or greater than this voltage causes leakage current through the ESD diodes at the input pins. This parameter is ensured by characterization and not 100% tested.

2: This input impedance is due to $3 . 2   \mathsf { p F }$ internal input sampling capacitor.

3: The total conversion speed includes auto-calibration of offset and gain.

4: INL is the difference between the endpoints line and the measured code at the center of the quantization band.

5: Includes all errors from on-board PGA and $\mathsf { V } _ { \mathsf { R E F } }$ F.

6: Full Scale Range (FSR) = 2 x 2.048/PGA = 4.096/PGA.

7: This parameter is ensured by characterization and not 100% tested.

8: This parameter is ensured by design and not 100% tested.