## 1.0 ELECTRICAL CHARACTERISTICS

## Absolute Maximum Ratings †

V<sub>DD</sub>........... .... 6.0V

Storage Temperature ........................ -65°C to +150°C

Ambient Temp. with Power Applied... -40°C to +150°C

Output Current ... .. ±30 mA

Junction Temperature (T<sub>J</sub>)............ .............. 150°C

ESD Protection on All Pins (HBM:MM) ......(2 kV:200V)

Latch-Up Current at Each Pin ....................... ±200 mA **† Notice:** Stresses above those listed under “Maximum Ratings” may cause permanent damage to the device. This is a stress rating only and functional operation of the device at those or any other conditions above those indicated in the operational listings of this specification is not implied. Exposure to maximum rating conditions for extended periods may affect device reliability.

DC ELECTRICAL CHARACTERISTICS

<table><tr><td colspan="7">Electrical Specifications: Unless otherwise indicated:MCP9700/9700A/9700B:  $V_{DD} = 2.3V$  to  $5.5V$ , GND = Ground,  $T_A = -40°C$  to  $+125°C$  and No loadMCP9701/9701A:  $V_{DD} = 3.1V$  to  $5.5V$ , GND = Ground,  $T_A = -10°C$  to  $+125°C$  and No load</td></tr><tr><td>Parameter</td><td>Sym.</td><td>Min.</td><td>Typ.</td><td>Max.</td><td>Unit</td><td>Conditions</td></tr><tr><td colspan="7">Power Supply</td></tr><tr><td rowspan="2">Operating Voltage Range</td><td> $V_{DD}$ </td><td>2.3</td><td>—</td><td>5.5</td><td>V</td><td>MCP9700/9700A/9700B</td></tr><tr><td> $V_{DD}$ </td><td>3.1</td><td>—</td><td>5.5</td><td>V</td><td>MCP9701/9701A</td></tr><tr><td rowspan="2">Operating Current</td><td> $I_{DD}$ </td><td>—</td><td>6</td><td>12</td><td>μA</td><td></td></tr><tr><td> $I_{DD}$ </td><td>—</td><td>—</td><td>15</td><td>μA</td><td> $T_A = +150°C (Note 1)$ </td></tr><tr><td>Line Regulation</td><td> $\Delta°C/\Delta V_{DD}$ </td><td>—</td><td>0.1</td><td>—</td><td>°C/V</td><td></td></tr><tr><td colspan="7">Sensor Accuracy (Notes 2, 3)</td></tr><tr><td> $T_A = +25°C$ </td><td> $T_{ACY}$ </td><td>—</td><td>±1</td><td>—</td><td>°C</td><td></td></tr><tr><td> $T_A = +20°C to +70°C$ </td><td> $T_{ACY}$ </td><td>-1.0</td><td>±0.5</td><td>+1.0</td><td>°C</td><td>MCP9700B</td></tr><tr><td> $T_A = 0°C to +125°C$ </td><td> $T_{ACY}$ </td><td>-2.0</td><td>±0.5</td><td>+3.0</td><td>°C</td><td>MCP9700B</td></tr><tr><td> $T_A = -40°C to +125°C$ </td><td> $T_{ACY}$ </td><td>-2.0</td><td>±0.5</td><td>+4.0</td><td>°C</td><td>MCP9700B</td></tr><tr><td> $T_A = 0°C to +70°C$ </td><td> $T_{ACY}$ </td><td>-2.0</td><td>±1</td><td>+2.0</td><td>°C</td><td>MCP9700A/9701A</td></tr><tr><td> $T_A = -40°C to +125°C$ </td><td> $T_{ACY}$ </td><td>-2.0</td><td>±1</td><td>+4.0</td><td>°C</td><td>MCP9700A</td></tr><tr><td> $T_A = -10°C to +125°C$ </td><td> $T_{ACY}$ </td><td>-2.0</td><td>±1</td><td>+4.0</td><td>°C</td><td>MCP9701A</td></tr><tr><td> $T_A = 0°C to +70°C$ </td><td> $T_{ACY}$ </td><td>-4.0</td><td>±2</td><td>+4.0</td><td>°C</td><td>MCP9700/9701</td></tr><tr><td> $T_A = -40°C to +125°C$ </td><td> $T_{ACY}$ </td><td>-4.0</td><td>±2</td><td>+6.0</td><td>°C</td><td>MCP9700</td></tr><tr><td> $T_A = -10°C to +125°C$ </td><td> $T_{ACY}$ </td><td>-4.0</td><td>±2</td><td>+6.0</td><td>°C</td><td>MCP9701</td></tr><tr><td> $T_A = -40°C to +150°C$ </td><td> $T_{ACY}$ </td><td>-4.0</td><td>±2</td><td>+6.0</td><td>°C</td><td>MCP9700High Temperature (Note 1)</td></tr><tr><td> $T_A = -40°C to +150°C$ </td><td> $T_{ACY}$ </td><td>-4.0</td><td>±2</td><td>+4.0</td><td>°C</td><td>MCP9700BHigh Temperature (Note 1)</td></tr><tr><td colspan="7">Sensor Output</td></tr><tr><td>Output Voltage,  $T_A = 0°C$ </td><td> $V_{0°C}$ </td><td>—</td><td>500</td><td>—</td><td>mV</td><td>MCP9700/9700A/9700B</td></tr></table>

Note 1: MCP9700 and MCP9700B with SC70-5 and SOT-23-3 packages only. The MCP9700 High Temperature is not available with TO-92 package.

2: The MCP9700/9700A/9700B family accuracy is tested with $V_{DD} = 3.3V$ while the MCP9701/9701A accuracy is tested with $V_{\mathrm{DD}} = 5.0V$

3: The MCP9700/9700A/9700B and MCP9701/9701A family is characterized using the first-order or linear equation, as shown in Equation 4-2. Also refer to Figure 2-17.

4: The MCP9700/9700A/9700B and MCP9701/9701A family is characterized and production tested with a capacitive load of 1000 pF.

5: SC70-5 package thermal response with 1x1 inch, dual-sided copper clad, TO-92-3 package thermal response without PCB (leaded).

DC ELECTRICAL CHARACTERISTICS (CONTINUED)

<table><tr><td colspan="7">Electrical Specifications: Unless otherwise indicated:MCP9700/9700A/9700B:  $V_{DD} = 2.3V$  to  $5.5V$ , GND = Ground,  $T_A = -40°C$  to  $+125°C$  and No loadMCP9701/9701A:  $V_{DD} = 3.1V$  to  $5.5V$ , GND = Ground,  $T_A = -10°C$  to  $+125°C$  and No load</td></tr><tr><td>Parameter</td><td>Sym.</td><td>Min.</td><td>Typ.</td><td>Max.</td><td>Unit</td><td>Conditions</td></tr><tr><td>Output Voltage,  $T_A = 0°C$ </td><td> $V_{0°C}$ </td><td>—</td><td>400</td><td>—</td><td>mV</td><td>MCP9701/9701A</td></tr><tr><td rowspan="2">Temperature Coefficient</td><td> $T_C$ </td><td>—</td><td>10.0</td><td>—</td><td>mV/°C</td><td>MCP9700/9700A/9700B</td></tr><tr><td> $T_C$ </td><td>—</td><td>19.5</td><td>—</td><td>mV/°C</td><td>MCP9701/9701A</td></tr><tr><td>Output Nonlinearity</td><td> $V_{ONL}$ </td><td>—</td><td>±0.5</td><td>—</td><td>°C</td><td> $T_A = 0°C$  to  $+70°C$  (Note 3)</td></tr><tr><td>Output Current</td><td> $I_{OUT}$ </td><td>—</td><td>—</td><td>100</td><td>μA</td><td></td></tr><tr><td>Output Impedance</td><td> $Z_{OUT}$ </td><td>—</td><td>20</td><td>—</td><td>Ω</td><td> $I_{OUT} = 100 μA, f = 500 Hz$ </td></tr><tr><td>Output Load Regulation</td><td> $\Delta V_{OUT}/\Delta I_{OUT}$ </td><td>—</td><td>2</td><td>—</td><td>Ω</td><td> $T_A = 0°C$  to  $+70°C$  $I_{OUT} = 100 μA$ </td></tr><tr><td>Turn-On Time</td><td> $t_{ON}$ </td><td>—</td><td>800</td><td>—</td><td>μs</td><td></td></tr><tr><td>Typical Load Capacitance</td><td> $C_{LOAD}$ </td><td>—</td><td>—</td><td>1000</td><td>pF</td><td>Note 4</td></tr><tr><td>SC-70 Thermal Response to 63%</td><td> $t_{RES}$ </td><td>—</td><td>1.3</td><td>—</td><td>s</td><td rowspan="2">30°C (Air) to  $+125°C$ (Fluid Bath) (Note 5)</td></tr><tr><td>TO-92 Thermal Response to 63%</td><td> $t_{RES}$ </td><td>—</td><td>1.65</td><td>—</td><td>s</td></tr></table>

Note 1: MCP9700 and MCP9700B with SC70-5 and SOT-23-3 packages only. The MCP9700 High Temperature is not available with TO-92 package.

2: The MCP9700/9700A/9700B family accuracy is tested with $V_{DD} = 3.3V$ while the MCP9701/9701A accuracy is tested with $V_{\mathrm{DD}} = 5.0V$

3: The MCP9700/9700A/9700B and MCP9701/9701A family is characterized using the first-order or linear equation, as shown in Equation 4-2. Also refer to Figure 2-17.

4: The MCP9700/9700A/9700B and MCP9701/9701A family is characterized and production tested with a capacitive load of 1000 pF.

5: SC70-5 package thermal response with 1x1 inch, dual-sided copper clad, TO-92-3 package thermal response without PCB (leaded).

TEMPERATURE CHARACTERISTICS

<table><tr><td colspan="7">Electrical Specifications: Unless otherwise indicated:MCP9700/9700A/9700B:  $V_{DD} = 2.3V$  to 5.5V, GND = Ground,  $T_A = -40°C$  to +125°C and No loadMCP9701/9701A:  $V_{DD} = 3.1V$  to 5.5V, GND = Ground,  $T_A = -10°C$  to +125°C and No load</td></tr><tr><td>Parameters</td><td>Sym.</td><td>Min.</td><td>Typ.</td><td>Max.</td><td>Units</td><td>Conditions</td></tr><tr><td colspan="7">Temperature Ranges</td></tr><tr><td rowspan="3">Specified Temperature Range (Note 1)</td><td> $T_A$ </td><td>-40</td><td>—</td><td>+125</td><td>°C</td><td>MCP9700/9700A/9700B</td></tr><tr><td> $T_A$ </td><td>-10</td><td>—</td><td>+125</td><td>°C</td><td>MCP9701/9701A</td></tr><tr><td> $T_A$ </td><td>-40</td><td>—</td><td>+150</td><td>°C</td><td>High Temperature(MCP9700 and MCP9700BSOT23-3 and SC70-5 only)</td></tr><tr><td rowspan="2">Operating Temperature Range</td><td> $T_A$ </td><td>-40</td><td>—</td><td>+125</td><td>°C</td><td>Extended Temperature</td></tr><tr><td> $T_A$ </td><td>-40</td><td>—</td><td>+150</td><td>°C</td><td>High Temperature</td></tr><tr><td>Storage Temperature Range</td><td> $T_A$ </td><td>-65</td><td>—</td><td>+150</td><td>°C</td><td></td></tr><tr><td colspan="7">Thermal Package Resistances</td></tr><tr><td>Thermal Resistance, 5LD SC70</td><td> $\theta_{JA}$ </td><td>—</td><td>331</td><td>—</td><td>°C/W</td><td></td></tr><tr><td>Thermal Resistance, 3LD SOT-23</td><td> $\theta_{JA}$ </td><td>—</td><td>308</td><td>—</td><td>°C/W</td><td></td></tr><tr><td>Thermal Resistance, 3LD TO-92</td><td> $\theta_{JA}$ </td><td>—</td><td>146</td><td>—</td><td>°C/W</td><td></td></tr></table>

Note 1: Operation in this range must not cause $\mathsf { T } _ { \mathsf { J } }$ to exceed Maximum Junction Temperature $(+150^{\circ}C)$