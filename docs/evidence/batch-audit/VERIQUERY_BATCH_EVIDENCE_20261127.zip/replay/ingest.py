"""Upload the frozen PDF samples and preserve MinerU's original output bytes."""
import hashlib
import json
from pathlib import Path
import re
import sys
import time
import fitz
import requests

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / "app/eval"))
from run_pilot import upload

base = "http://127.0.0.1:8001/v1"
api = "http://127.0.0.1:8298"
for url in (f"{api}/health", f"{base}/models", "http://127.0.0.1:9997/v1/models/bge-m3"):
    for _ in range(100):
        try:
            res = requests.get(url, timeout=3)
            if res.ok or url == f"{base}/models" and res.status_code == 404:
                break
        except requests.RequestException:
            pass
        time.sleep(2)
    else:
        raise RuntimeError(url)

docs = {}
for pdf in sorted((root/"inputs").glob("*.pdf")):
    dest = root/"raw"/pdf.stem
    dest.mkdir(exist_ok=True)
    with fitz.open(pdf) as source:
        for i, page in enumerate(source, 1):
            (dest/f"pdf-page-{i}.txt").write_text(page.get_text(sort=True), encoding="utf8")
    path = root/"mineru.log"
    offset = path.stat().st_size
    doc = upload(api, pdf, 825)
    if (doc["parser"], doc["parser_tier"], doc["page_count"]) != ("mineru", "advanced", 2):
        raise RuntimeError(doc)
    jobs = set(re.findall(rb"/v1/parse/jobs/(job_[a-zA-Z0-9_-]+)", path.read_bytes()[offset:]))
    matching = []
    for job_id in jobs:
        res = requests.get(f"{base}/parse/jobs/{job_id.decode()}", timeout=20)
        res.raise_for_status()
        if any(x["name"] == f"{doc['document_id']}_{pdf.name}" for x in res.json()["files"]):
            matching.append((job_id, res))
    (job_id, res), = matching
    (dest/"job.json").write_bytes(res.content)
    job = res.json()
    assert job["status"] == "completed"
    for kind, suffix in (("structured_content","json"),("middle_json","json"),("markdown","md")):
        ref = job["files"][0]["output_files"][kind]
        raw = requests.get(f"{base}/files/{ref['file_id']}/content", timeout=90)
        raw.raise_for_status()
        (dest/f"{kind}.{suffix}").write_bytes(raw.content)
    docs[pdf.stem] = {**doc, "sample_sha256":hashlib.sha256(pdf.read_bytes()).hexdigest()}
    (root/"documents.json").write_text(json.dumps(docs, ensure_ascii=False, indent=2), encoding="utf8")
    print(pdf.stem,doc["document_id"], doc["chunk_count"], job_id.decode(), flush=True)
