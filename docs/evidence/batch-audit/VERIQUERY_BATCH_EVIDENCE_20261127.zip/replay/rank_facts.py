"""Track reviewed row signatures through the retrieval and context stages."""
import json
from pathlib import Path
import re
import sys
import unicodedata

root=Path(sys.argv[1])
signatures=json.loads((root/"row-signatures.json").read_text(encoding="utf8"))
gold=json.loads((root/"gold.json").read_text(encoding="utf8"))
questions=[json.loads(l) for l in (root/"questions.jsonl").read_text(encoding="utf8").splitlines()]
documents=json.loads((root/"documents.json").read_text(encoding="utf8"))
pages={"24LC256":[3,4],"MCP3421":[3,4],"MCP9700":[3,4],"OPA2993":[6,7],"SN65HVD230":[6,7]}


def normalize(s):
    s=unicodedata.normalize("NFKC",s).casefold()
    s=re.sub(r"\[跨\d+[列行]合并\]", "", s)
    s=re.sub(r"\\(?:mathrm|text|mathsf|left|right)\b","",s)
    s=re.sub(r"(?<=\|)\s*(?:min|typ|max)\s*:\s*(?=[+-]?\d)", "", s)
    return re.sub(r"[\s{}_$\\]+","",s).replace("−","-").replace("–","-").replace("—","-").replace("µ","μ")


def hits(rows, document, page, pattern):
    matches=[]
    for i,r in enumerate(rows,1):
        ident=r.get("doc",r.get("document_id"))
        if ident==document and r["page"]==page:
            s=normalize(r["text"])
            if (match:=pattern.search(s)):
                matches.append({"rank":i,"chunk_id":r.get("id",r.get("chunk_id")),"signature":match[0]})
    return matches


result={}
for q in questions:
    rec=json.loads((root/"cases"/f"{q['id']}.json").read_text(encoding="utf8"))
    api=rec["api"]["response"]
    tr=api["trace"]
    context=next((e for e in rec["events"] if e["stage"]=="assembled"),None)
    visible=[]
    if context:
        body=context["context"]
        marks=list(re.finditer(r"(?m)^\[(\d+)\] [^\n]+? 第(\d+)页",body))
        assert len(marks)==len(context["sources"])
        for j,m in enumerate(marks):
            end=marks[j+1].start() if j+1<len(marks) else len(body)
            visible.append({**context["sources"][j],"text":body[m.end():end]})
    if not context and tr["context_evidence"]:
        visible=[{**r,"text":r["text_snippet"]} for r in tr["context_evidence"]]
    for key in q["facts"]:
        g=gold[key]
        doc=documents[g["doc"]]["document_id"]
        page=pages[g["doc"]].index(g["page"])+1
        m=re.compile(signatures[key])
        fact={"question":q["id"],"session":rec["api"]["request"]["session_id"],"marks":{}}
        for scope,name in [("dense","_vector_retrieve_output"),("bm25","retrieve_lexical_output"),
                           ("table","_table_retrieve_output"),("rrf","_rrf_fusion_output"),
                           ("rerank","_rerank_candidates_output")]:
            fact["marks"][scope]=[hit for e in rec["events"] if e["stage"]==name for hit in hits(e["hits"],doc,page,m)]
        fact["marks"]["returned"]=hits(tr["retrieved"],doc,page,m)
        fact["marks"]["context"]=hits(visible,doc,page,m)
        fact["marks"]["citations"]=hits([{**r,"text":r["text_snippet"]} for r in api["citations"]],doc,page,m)
        result[key]=fact
print(json.dumps(result,ensure_ascii=False,indent=2))
