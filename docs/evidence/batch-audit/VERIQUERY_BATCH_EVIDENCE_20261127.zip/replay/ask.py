"""Replay frozen questions on the observed production API."""
import json
from pathlib import Path
import sys
from uuid import uuid4

import requests

root = Path(sys.argv[1])
ids = set(sys.argv[2].split(","))
docs = json.loads((root / "documents.json").read_text())
questions = [json.loads(line) for line in (root/"questions.jsonl").read_text().splitlines()]
with requests.Session() as http, (root/"answers.jsonl").open("x",encoding="utf8") as out:
    for q in questions:
        if q["id"] not in ids:
            continue
        request = {"query":q["query"], "document_ids":[docs[n]["document_id"] for n in q["parts"]],
                   "session_id":str(uuid4()), "trace":True}
        r = http.post("http://127.0.0.1:8291/api/v1/chat/",json=request,timeout=240)
        r.raise_for_status()
        answer = r.json()
        if answer["session_id"] != request["session_id"] or not answer["success"]:
            raise RuntimeError((q["id"], answer))
        print(json.dumps({"id":q["id"], "request":request, "status":r.status_code, "response":answer},
                         ensure_ascii=False),file=out,flush=True)
        print(q["id"],request["session_id"], answer["trace"]["answer_mode"],flush=True)
