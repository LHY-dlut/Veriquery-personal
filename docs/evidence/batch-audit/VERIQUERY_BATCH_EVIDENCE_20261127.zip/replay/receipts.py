"""Extract the documents, candidate orders, and generation evidence for each case."""
from collections import defaultdict
import json
from pathlib import Path
import re
import sys


root=Path(sys.argv[1])


def lines(path):
    return [json.loads(x) for x in path.read_text(encoding="utf8").splitlines()]


events=defaultdict(list)
for event in lines(root/"events.jsonl"):
    events[event["session"]].append(event)
docs=json.loads((root/"documents.json").read_text(encoding="utf8"))
questions={q["id"]:q for q in lines(root/"questions.jsonl")}
dest=root/"cases"
dest.mkdir(exist_ok=True)
results={}
for record in lines(root/"answers.jsonl"):
    id_=record["id"]
    request=record["request"]
    prediction=record["response"]
    trace=prediction["trace"]
    case_events=events[request["session_id"]]
    scope=sorted(docs[p]["document_id"] for p in questions[id_]["parts"])
    entry=next(e["arguments"] for e in case_events if e["stage"]=="graph_entry")
    assert entry["query"]==request["query"]==questions[id_]["query"]
    assert sorted(entry["doc_ids"])==sorted(request["document_ids"])==scope
    calls=[e for e in case_events if e.get("path","").endswith("/chat/completions")]
    if calls:
        assert calls[0]["request"]["max_tokens"]==512
        assert trace["context"] in calls[0]["request"]["messages"][0]["content"]
    assert all(c["reply"]["model"]=="qwen3.5" for c in calls)
    by_branch=defaultdict(dict)
    for e in case_events:
        if e["branch"]:
            key=e.get("path",e["stage"])
            by_branch[e["branch"]][key]=e
    for branch in by_branch.values():
        fusion=branch.get("_rrf_fusion_input")
        if fusion:
            rows_by_source=defaultdict(list)
            for hit in fusion["hits"]:
                rows_by_source[hit["source"]].append(hit)
            scores=defaultdict(float)
            for source,rows in rows_by_source.items():
                for i,h in enumerate(sorted(rows,key=lambda h:-h["score"]),1):
                    scores[h["doc"],h["id"]]+=fusion["weights"].get(source,.1)/(fusion["args"]["k"]+i)
            for h in branch["_rrf_fusion_output"]["hits"]:
                assert abs(h["metadata"]["rrf_score"]-scores[h["doc"],h["id"]])<1e-10
        wire=branch.get("/v1/rerank")
        if wire:
            candidates=branch["_rerank_candidates_input"]["hits"]
            sent=[]
            for h in candidates:
                m=h["metadata"]
                sent.append("\n".join(filter(None,[m.get("table_header"),m.get("focused_text") or h["text"]]))
                            if m.get("focused_row") else h["text"])
            assert sent==wire["request"]["documents"]
            indexed={v["index"]:v["relevance_score"] for v in wire["reply"]["results"]}
            expected=[candidates[i]["id"] for i in sorted(indexed,key=indexed.get,reverse=True)]
            expected.extend(h["id"] for i,h in enumerate(candidates) if i not in indexed)
            assert expected==[h["id"] for h in branch["_rerank_candidates_output"]["hits"]]
    (dest/f"{id_}.json").write_text(json.dumps({"api":record,"events":case_events},
                                            ensure_ascii=False,indent=2),encoding="utf8")
    results[id_]=dict(session=request["session_id"], route=trace["answer_mode"],
                      model_calls=len(calls), first_model_tokens=calls[0]["reply"]["usage"].get("completion_tokens") if calls else None,
                      candidate_counts={b:{k:len(e.get("hits",e.get("rows",[]))) for k,e in events.items()
                                           if "rows" in e or "hits" in e} for b,events in by_branch.items()})
print(json.dumps(results,ensure_ascii=False,indent=2))
