"""Aggregate a per-field human evidence review and enforce denominator consistency."""
import csv
import json
from pathlib import Path
import sys

root=Path(sys.argv[1])
gold=json.loads((root/"gold.json").read_text(encoding="utf8"))
questions={q["id"]:q for q in map(json.loads,(root/"questions.jsonl").read_text(encoding="utf8").splitlines())}
with (root/"field-review.csv").open(encoding="utf-8-sig",newline="") as f:
    checks=list(csv.DictReader(f))
with (root/"answer-review.csv").open(encoding="utf-8-sig",newline="") as f:
    answers=list(csv.DictReader(f))
assert len(checks)==len(gold)
assert {r["fact"] for r in checks}==set(gold)
assert len(answers)==len(questions) and {r["question"] for r in answers}==set(questions)
by_fact={r["fact"]:r for r in checks}
by_topic={fact:q for q,row in questions.items() for fact in row["facts"]}
summary={}
for stage in ("parsed","indexed","dense","bm25","table","union","rrf8","rerank1","rerank8","context","unambiguous_context","selected_field"):
    assert all(row[stage] in ("0","1") for row in checks)
    summary[stage]={"passed":sum(int(row[stage]) for row in checks),"total":len(checks)}
for fact,row in by_fact.items():
    assert row["question"]==by_topic[fact] and row["evidence"]
    assert int(row["union"])==max(int(row[k]) for k in ("dense","bm25","table"))
    assert int(row["rerank1"])<=int(row["rerank8"])
    assert int(row["unambiguous_context"])<=int(row["context"])
for row in answers:
    assert row["strict"] in ("0","1")
    assert row["reason"]
    if row["strict"]=="1":
        assert all(by_fact[f]["selected_field"]=="1" for f in questions[row["question"]]["facts"])
summary["strict"]={"passed":sum(int(row["strict"]) for row in answers),"total":len(answers)}
usable=[r for r in checks if r["parsed"]=="1" and r["indexed"]=="1"]
summary["among_preserved_fields"]={
    stage:{"passed":sum(int(r[stage]) for r in usable),"total":len(usable)}
    for stage in ("union","rrf8","rerank1","rerank8","context","unambiguous_context")
}
print(json.dumps(summary,ensure_ascii=False,indent=2))
