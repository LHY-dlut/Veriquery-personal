set -euo pipefail
r=$1
cd "$r/app"
prev=/root/autodl-tmp/veriquery-formula-ab.hqPa8I
py=/root/autodl-tmp/Veriquery-personal/.venv/bin/python
source "$prev/runtime-env.sh" "$PWD" 8291 qwen3.5 http://127.0.0.1:9997/v1
export LLM_MAX_TOKENS=512
"$py" "$r/observe.py" "$r/events.jsonl" 8291 >"$r/chat-api.log" 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT
for i in $(seq 1 90); do
    curl -fsS --max-time 2 http://127.0.0.1:8291/health >/dev/null 2>&1 && break
    kill -0 "$pid"
    sleep 1
done
"$py" "$r/ask.py" "$r" e01,e02,e03,a01,a02,a03,t01,t02,t03,o01,o02,o03,c01,c02,c03,c04
