"""Make MinerU table row order, cells and spans easy to review."""
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys


class TableReader(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows = []
        self.row = None
        self.cell = None

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self.row = []
        elif tag in ("th", "td") and self.row is not None:
            attrs = dict(attrs)
            self.cell = {"rowspan":int(attrs.get("rowspan", "1")),
                         "colspan":int(attrs.get("colspan", "1")), "parts":[]}

    def handle_data(self, data):
        if self.cell is not None:
            self.cell["parts"].append(data)

    def handle_endtag(self, tag):
        if tag in ("th", "td") and self.cell is not None:
            self.cell["text"] = " ".join(" ".join(self.cell.pop("parts")).split())
            self.row.append(self.cell)
            self.cell = None
        elif tag == "tr" and self.row is not None:
            self.rows.append(self.row)
            self.row = None

    def expanded(self):
        carry = {}
        rows = []
        for row in self.rows:
            entries = {col: val[0] for col,val in carry.items()}
            carry = {col: (cell, left-1) for col,(cell,left) in carry.items() if left > 1}
            col = 0
            for cell in row:
                while col in entries:
                    col += 1
                for at in range(col,col+cell["colspan"]):
                    entries[at]=cell["text"]
                    if cell["rowspan"]>1:
                        carry[at]=cell["text"],cell["rowspan"]-1
                col+=cell["colspan"]
            rows.append([entries.get(at,"") for at in range(max(entries,default=-1)+1)])
        return rows


def rows_of(content):
    if isinstance(content,str):
        if "<table" in content.lower():
            parser=TableReader()
            parser.feed(content)
            return parser.expanded()
        return [[s.strip() for s in row.strip().strip("|").split("|")]
                for row in content.splitlines() if "|" in row and not re.fullmatch(r"[\s|:-]+",row)]
    return []


root = Path(sys.argv[1])
out = {}
for f in sorted(root.glob("*/structured_content.json")):
    part = f.parent.name
    payload = json.loads(f.read_text(encoding="utf8"))
    tables = []
    for page in payload["pages"]:
        for i, block in enumerate(page["blocks"]):
            if block["type"] == "table":
                tables.append({"page":page["page_idx"]+1, "block":i, "bbox":block.get("bbox"),
                               "rows":rows_of(block.get("content"))})
    out[part] = tables
print(json.dumps(out,ensure_ascii=False,indent=2))
